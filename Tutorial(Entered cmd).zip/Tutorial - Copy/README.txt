Before do anything,
You must install node.js
After installed and configured node.js, Enter this command:
*npm install discord.js*
to connect to Discord Api.

Then enter this command:
*npm init*
to show your folder andress.

Please enter these commands on command prompt or terminal in VS CODE.